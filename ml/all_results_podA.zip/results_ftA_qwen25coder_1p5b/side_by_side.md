# Base vs fine-tuned: examples


## humaneval: fine-tuned passes, base fails = 15, base passes, fine-tuned fails = 9, both fail = 52


### humaneval HumanEval/6 (fine-tuned passes, base fails)
**Base:**
```
```python
from typing import List

def parse_nested_parens(paren_string: str) -> List[int]:
    """ Input to this function is a string represented multiple groups for nested parentheses separated by spaces.
    For each of the group, output the deepest level of nesting of parentheses.
    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """
    result = []
    current_depth = 0
    max_depth = 0

    for char in paren_string:
        if char == '(':
            current_depth += 1
            max_depth = max(max_depth, current_depth)
        elif char == ')':
            current_depth -= 1

    return result
```
```
**Fine-tuned:**
```
```python
from typing import List

def parse_nested_parens(paren_string: str) -> List[int]:
    """ Input to this function is a string represented multiple groups for nested parentheses separated by spaces.
    For each of the group, output the deepest level of nesting of parentheses.
    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """
    result = []
    for group in paren_string.split():
        max_depth = 0
        current_depth = 0
        for char in group:
            if char == '(':
                current_depth += 1
                max_depth = max(max_depth, current_depth)
            elif char == ')':
                current_depth -= 1
        result.append(max_depth)
    return result
```
```


### humaneval HumanEval/11 (fine-tuned passes, base fails)
**Base:**
```
```python
from typing import List

def string_xor(a: str, b: str) -> str:
    """ Input are two strings a and b consisting only of 1s and 0s.
    Perform binary XOR on these inputs and return result also as a string.
    >>> string_xor('010', '110')
    '100'
    """
    # Ensure both strings are of equal length
    if len(a) != len(b):
        raise ValueError("Both input strings must be of equal length.")
    
    # Perform binary XOR operation
    xor_result = ''.join(['1' if x == y else '0' for x, y in zip(a, b)])
    
    return xor_result
```
```
**Fine-tuned:**
```
```python
from typing import List

def string_xor(a: str, b: str) -> str:
    """ Input are two strings a and b consisting only of 1s and 0s.
    Perform binary XOR on these inputs and return result also as a string.
    >>> string_xor('010', '110')
    '100'
    """
    xor_result = ''
    for char_a, char_b in zip(a, b):
        xor_result += str(int(char_a) ^ int(char_b))
    return xor_result
```
```


### humaneval HumanEval/55 (fine-tuned passes, base fails)
**Base:**
```
```python
def fib(n: int):
    """Return n-th Fibonacci number.
    >>> fib(10)
    55
    >>> fib(1)
    1
    >>> fib(8)
    21
    """
    if n <= 0:
        return "Input should be a positive integer."
    elif n == 1:
        return 1
    else:
        a, b = 0, 1
        for _ in range(2, n + 1):
            a, b = b, a + b
        return b
```
```
**Fine-tuned:**
```
```python
def fib(n: int):
    """Return n-th Fibonacci number.
    >>> fib(10)
    55
    >>> fib(1)
    1
    >>> fib(8)
    21
    """
    if n <= 1:
        return n
    else:
        a, b = 0, 1
        for _ in range(2, n + 1):
            a, b = b, a + b
        return b
```
```


### humaneval HumanEval/33 (base passes, fine-tuned fails)
**Base:**
```
```python
from typing import List

def sort_third(l: List[int]) -> List[int]:
    # Extract elements at indices divisible by 3
    third_elements = [l[i] for i in range(0, len(l), 3)]
    
    # Sort these elements
    third_elements.sort()
    
    # Replace the original elements at indices divisible by 3 with the sorted elements
    for i, value in enumerate(third_elements):
        l[i * 3] = value
    
    return l
```
```
**Fine-tuned:**
```
```python
from typing import *
from collections import *

def sort_third(l: list):
    """This function takes a list l and returns a list l' such that
    l' is identical to l in the indicies that are not divisible by three, while its values at the indicies that are divisible by three are equal
    to the values of the corresponding indicies of l, but sorted.
    >>> sort_third([1, 2, 3])
    [1, 2, 3]
    >>> sort_third([5, 6, 3, 4, 8, 9, 2])
    [2, 6, 3, 4, 8, 9, 5]
    """
    # Create a copy of the list l
    l_prime = l[:]
    
    # Sort the elements at indices divisible by three
    for i in range(0, len(l), 3):
        l_prime[i] = sorted(l_prime[i:i+3])[0]
        
    return l_prime
```
```


### humaneval HumanEval/63 (base passes, fine-tuned fails)
**Base:**
```
```python

from typing import *
from collections import *

def fibfib(n: int) -> int:
    if n < 2:
        return 0
    elif n == 2:
        return 1
    else:
        a, b, c = 0, 0, 1
        for _ in range(3, n+1):
            a, b, c = b, c, a + b + c
        return c
```
```
**Fine-tuned:**
```
```python
from typing import *
from collections import *

def fibfib(n: int):
    if n < 3:
        return [0, 0, 1][n]
    
    fibfib_cache = [0, 0, 1] + [None] * (n - 3)
    
    def fibfib_helper(i):
        if fibfib_cache[i] is None:
            fibfib_cache[i] = fibfib_helper(i - 1) + fibfib_helper(i - 2) + fibfib_helper(i - 3)
        return fibfib_cache[i]
    
    return fibfib_helper(n)
```
```


### humaneval HumanEval/64 (base passes, fine-tuned fails)
**Base:**
```
```python
FIX = """
Add more test cases.
"""

def vowels_count(s):
    """Write a function vowels_count which takes a string representing
    a word as input and returns the number of vowels in the string.
    Vowels in this case are 'a', 'e', 'i', 'o', 'u'. Here, 'y' is also a
    vowel, but only when it is at the end of the given word.

    Example:
    >>> vowels_count("abcde")
    2
    >>> vowels_count("ACEDY")
    3
    """
    # Initialize count to zero
    count = 0
    
    # Convert the string to lowercase for uniformity
    s = s.lower()
    
    # Check each character in the string
    for char in s:
        if char in "aeiou":
            count += 1
    
    # Check if 'y' is at the end of the string
    if s.endswith('y'):
        count += 1
    
    return count
```
```
**Fine-tuned:**
```
```python
FIX = """
Add more test cases.
"""

def vowels_count(s):
    """Write a function vowels_count which takes a string representing
    a word as input and returns the number of vowels in the string.
    Vowels in this case are 'a', 'e', 'i', 'o', 'u'. Here, 'y' is also a
    vowel, but only when it is at the end of the given word.

    Example:
    >>> vowels_count("abcde")
    2
    >>> vowels_count("ACEDY")
    3
    """

    count = sum(1 for char in s if char.lower() in "aeiou" or (char == "y" and len(s) > 1))
    return count
```
```


### humaneval HumanEval/1 (both fail)
**Base:**
```
```python
from typing import List

def separate_paren_groups(paren_string: str) -> List[str]:
    paren_string = paren_string.replace(" ", "")  # Remove spaces from the input string
    stack = []
    result = []

    for char in paren_string:
        if char == '(':
            stack.append(char)
        elif char == ')':
            if stack:
                stack.pop()
            else:
                raise ValueError("Unmatched closing parenthesis")
        
        if len(stack) == 0:
            result.append(''.join(stack))

    return result
```
```
**Fine-tuned:**
```
```python
from typing import List

def separate_paren_groups(paren_string: str) -> List[str]:
    paren_string = paren_string.replace(" ", "")  # Remove spaces from the input string
    stack = []
    result = []

    for char in paren_string:
        if char == "(":
            stack.append(char)
        elif char == ")":
            if stack:
                stack.pop()
                if not stack:
                    result.append("".join(stack))
                    stack.clear()

    return result
```
```


### humaneval HumanEval/10 (both fail)
**Base:**
```
```python
def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]

def make_palindrome(string: str) -> str:
    """ Find the shortest palindrome that begins with a supplied string.
    Algorithm idea is simple:
    - Find the longest postfix of supplied string that is a palindrome.
    - Append to the end of the string reverse of a string prefix that comes before the palindromic suffix.
    >>> make_palindrome('')
    ''
    >>> make_palindrome('cat')
    'catac'
    >>> make_palindrome('cata')
    'catac'
    """
    if not string:
        return ""
    
    # Find the longest suffix that is a palindrome
    for i in range(len(string), 0, -1):
        if string[:i] == string[:i][::-1]:
            # Append the reverse of the prefix before the palindrome suffix
            return string + string[i-1::-1]
    
    # If no 
```
**Fine-tuned:**
```
```python
from typing import *
from collections import *

def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]

def make_palindrome(string: str) -> str:
    """ Find the shortest palindrome that begins with a supplied string.
    Algorithm idea is simple:
    - Find the longest postfix of supplied string that is a palindrome.
    - Append to the end of the string reverse of a string prefix that comes before the palindromic suffix.
    >>> make_palindrome('')
    ''
    >>> make_palindrome('cat')
    'catac'
    >>> make_palindrome('cata')
    'catac'
    """
    # Find the longest palindromic suffix
    for i in range(len(string), 0, -1):
        if string[i-1:] == string[:i]:
            break

    # Reverse the non-palindromic prefix and append it to the end
    return string + string[:len(string)-i][::-1]
```
```


### humaneval HumanEval/19 (both fail)
**Base:**
```
```python
from typing import List

def sort_numbers(numbers: str) -> str:
    """ Input is a space-delimited string of numberals from 'zero' to 'nine'.
    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight' and 'nine'.
    Return the string with numbers sorted from smallest to largest
    >>> sort_numbers('three one five')
    'one three five'
    """
    # Mapping of number words to their numeric values
    num_map = {
        "zero": 0, "one": 1, "two": 2, "three": 3, "four": 4,
        "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9
    }
    
    # Splitting the input string into individual number words
    words = numbers.split()
    
    # Converting each word to its corresponding numeric value
    nums = [num_map[word] for word in words]
    
    # Sorting the list of numbers
    nums.sort()
    
    # Converting the sorted list back to
```
**Fine-tuned:**
```
```python
from typing import List

def sort_numbers(numbers: str) -> str:
    """ Input is a space-delimited string of numberals from 'zero' to 'nine'.
    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight' and 'nine'.
    Return the string with numbers sorted from smallest to largest
    >>> sort_numbers('three one five')
    'one three five'
    """
    # Mapping of number words to their numeric values
    num_map = {
        "zero": 0,
        "one": 1,
        "two": 2,
        "three": 3,
        "four": 4,
        "five": 5,
        "six": 6,
        "seven": 7,
        "eight": 8,
        "nine": 9
    }

    # Split the input string into individual number words
    words = numbers.split()

    # Convert each word to its corresponding numeric value
    nums = [num_map[word] for word in words]

    # Sort the numeric values
    nums.sort()

   
```


## mbpp: fine-tuned passes, base fails = 34, base passes, fine-tuned fails = 29, both fail = 132


### mbpp 4 (fine-tuned passes, base fails)
**Base:**
```
```python
def heap_queue_largest(numbers, n):
    # Convert the list into a max-heap
    import heapq
    heapq.heapify(numbers)
    
    # Extract the top 'n' elements from the heap
    largest_numbers = heapq.nlargest(n, numbers)
    
    return largest_numbers[::-1]
```
```
**Fine-tuned:**
```
```python
import heapq

def heap_queue_largest(numbers, n):
    # Use nlargest from heapq to get the n largest elements
    return heapq.nlargest(n, numbers)
```
```


### mbpp 12 (fine-tuned passes, base fails)
**Base:**
```
```python
def sort_matrix(matrix):
    # Calculate the sum of each row
    row_sums = [sum(row) for row in matrix]
    
    # Sort the matrix based on the sums of its rows
    sorted_matrix = sorted(matrix, key=row_sums)
    
    return sorted_matrix
```
```
**Fine-tuned:**
```
```python
def sort_matrix(matrix):
    # Calculate the sum of each row
    sums = [[sum(row) for row in matrix]]
    
    # Sort the matrix based on the sum of rows
    sorted_matrix = sorted(matrix, key=lambda x: sums[0][matrix.index(x)])
    
    return sorted_matrix
```
```


### mbpp 71 (fine-tuned passes, base fails)
**Base:**
```
```python
def comb_sort(arr):
    n = len(arr)
    gap = n // 2

    while gap > 0:
        for i in range(0, n - gap, gap):
            if arr[i] > arr[i + gap]:
                arr[i], arr[i + gap] = arr[i + gap], arr[i]

        gap //= 2

    return arr
```
```
**Fine-tuned:**
```
```python
def comb_sort(arr):
    gap = len(arr)
    shrink_factor = 1.3
    while gap > 1 or any(arr[i] > arr[i + 1] for i in range(len(arr) - 1)):
        gap = int(gap / shrink_factor)
        if gap < 1:
            gap = 1
        for i in range(len(arr) - gap):
            if arr[i] > arr[i + gap]:
                arr[i], arr[i + gap] = arr[i + gap], arr[i]
    return arr
```
```


### mbpp 16 (base passes, fine-tuned fails)
**Base:**
```
```python
def text_lowercase_underscore(text):
    # Check if the input is a string
    if not isinstance(text, str):
        return False
    
    # Split the string by underscores
    parts = text.split('_')
    
    # Check if all parts are lowercase letters
    for part in parts:
        if not part.islower():
            return False
    
    # If all parts are lowercase letters, return True
    return True
```
```
**Fine-tuned:**
```
```python
def text_lowercase_underscore(text):
    return all(c.islower() for c in text.split('_')) and len(text.split('_')) > 1
```
```


### mbpp 63 (base passes, fine-tuned fails)
**Base:**
```
```python
def max_difference(pairs):
    # Calculate the absolute differences between each pair of elements
    differences = [abs(a - b) for a, b in pairs]
    
    # Return the maximum difference found
    return max(differences)
```
```
**Fine-tuned:**
```
```python
def max_difference(pairs):
    # Sort the pairs based on the second element of each pair
    sorted_pairs = sorted(pairs, key=lambda x: x[1])
    
    # Initialize the maximum difference to zero
    max_diff = 0
    
    # Iterate through the sorted pairs and calculate the difference between consecutive pairs
    for i in range(len(sorted_pairs) - 1):
        diff = sorted_pairs[i+1][0] - sorted_pairs[i][1]
        
        # Update the maximum difference if the current difference is greater
        if diff > max_diff:
            max_diff = diff
            
    return max_diff
```
```


### mbpp 72 (base passes, fine-tuned fails)
**Base:**
```
```python
def dif_Square(n):
    # A number can be expressed as the difference of two squares if and only if it is not of the form 4k+2
    return n % 4 != 2
```
```
**Fine-tuned:**
```
```python
def dif_Square(n):
    return n % 4 != 0
```
```


### mbpp 6 (both fail)
**Base:**
```
```python
def differ_At_One_Bit_Pos(num1, num2):
    # XOR the two numbers
    xor_result = num1 ^ num2
    
    # Count the number of set bits (bits that are 1)
    count_of_set_bits = bin(xor_result).count('1')
    
    # If there is exactly one set bit, return True
    return count_of_set_bits == 1
```
```
**Fine-tuned:**
```
```python
def differ_At_One_Bit_Pos(a, b):
    return bin(a ^ b).count('1') == 1
```
```


### mbpp 7 (both fail)
**Base:**
```
```python
def find_char_long(text):
    # Splitting the text into words using space as the delimiter
    words = text.split()
    
    # Filtering out words that are less than 4 characters long
    char_long_words = [word for word in words if len(word) >= 4]
    
    return set(char_long_words)
```
```
**Fine-tuned:**
```
```python
def find_char_long(text):
    return {word for word in text.split() if len(word) >= 4}
```
```


### mbpp 9 (both fail)
**Base:**
```
```python
def find_Rotations(s):
    # Check if the input string is empty or has only one character
    if len(s) <= 1:
        return 0
    
    # Concatenate the string with itself
    doubled_string = s + s
    
    # Find the index where the original string appears in the doubled string
    rotation_index = doubled_string.find(s)
    
    # Calculate the number of rotations needed
    rotations_needed = rotation_index // len(s)
    
    return rotations_needed
```
```
**Fine-tuned:**
```
```python
def find_Rotations(s):
    return len(s) - s.rfind(s[0])
```
```
