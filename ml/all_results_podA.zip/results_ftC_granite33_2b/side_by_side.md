# Base vs fine-tuned: examples


## humaneval: fine-tuned passes, base fails = 14, base passes, fine-tuned fails = 20, both fail = 66


### humaneval HumanEval/17 (fine-tuned passes, base fails)
**Base:**
```
```python
from typing import List

def parse_music(music_string: str) -> List[int]:
    beats = []
    for note in music_string:
        if note == 'o':
            beats.append(4)
        elif note == 'o|':
            beats.append(2)
        elif note == '.|':
            beats.append(1)
    return beats
```
```
**Fine-tuned:**
```
```python
from typing import List

def parse_music(music_string: str) -> List[int]:
    """ Input to this function is a string representing musical notes in a special ASCII format.
    Your task is to parse this string and return list of integers corresponding to how many beats does each
    not last.

    Here is a legend:
    'o' - whole note, lasts four beats
    'o|' - half note, lasts two beats
    '.|' - quater note, lasts one beat

    >>> parse_music('o o| .| o| o| .| .| .| .| o o')
    [4, 2, 1, 2, 2, 1, 1, 1, 1, 4, 4]
    """
    music_list = music_string.split()
    result = []
    for note in music_list:
        if note == 'o':
            result.append(4)
        elif note == 'o|':
            result.append(2)
        elif note == '.|':
            result.append(1)
    return result
```
```


### humaneval HumanEval/44 (fine-tuned passes, base fails)
**Base:**
```
```python
def change_base(x: int, base: int):
    """Change numerical base of input number x to base.
    return string representation after the conversion.
    base numbers are less than 10.
    """
    if base < 2 or base > 10:
        raise ValueError("Base must be between 2 and 10.")
    return ''.join(str(x % base) for _ in range(base.bit_length()))[::-1]
```
```
**Fine-tuned:**
```
```python
def change_base(x: int, base: int):
    """Change numerical base of input number x to base.
    return string representation after the conversion.
    base numbers are less than 10.
    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """
    if x < 0:
        return '-' + change_base(-x, base)
    elif x < base:
        return str(x)
    else:
        return change_base(x // base, base) + str(x % base)
```
```


### humaneval HumanEval/46 (fine-tuned passes, base fails)
**Base:**
```
```python
def fib4(n: int):
    if n < 0:
        raise ValueError("Input should be a non-negative integer.")
    elif n == 0:
        return 0
    elif n == 1 or n == 2:
        return 0
    elif n == 3:
        return 2
    else:
        a, b, c, d = 0, 0, 2, 0
        for i in range(4, n+1):
            a, b, c, d = b, c, d, a + b + c + d
        return d
```
```
**Fine-tuned:**
```
```python
def fib4(n: int):
    if n < 0:
        raise ValueError("Input must be a non-negative integer")
    if n == 0:
        return 0
    if n == 1:
        return 0
    if n == 2:
        return 2
    if n == 3:
        return 0
    a, b, c, d = 0, 0, 2, 0
    for i in range(4, n + 1):
        a, b, c, d = b, c, d, a + b + c + d
    return d
```
```


### humaneval HumanEval/9 (base passes, fine-tuned fails)
**Base:**
```
```python
from typing import List, Tuple


def rolling_max(numbers: List[int]) -> List[int]:
    """ From a given list of integers, generate a list of rolling maximum element found until given moment
    in the sequence.
    >>> rolling_max([1, 2, 3, 2, 3, 4, 2])
    [1, 2, 3, 3, 3, 4, 4]
    """
    result = []
    for num in numbers:
        result.append(max(result[-1] if result else num, num))
    return result
```
```
**Fine-tuned:**
```
```python
from typing import List, Tuple


def rolling_max(numbers: List[int]) -> List[int]:
    """ From a given list of integers, generate a list of rolling maximum element found until given moment
    in the sequence.
    >>> rolling_max([1, 2, 3, 2, 3, 4, 2])
    [1, 2, 3, 3, 3, 4, 4]
    """
    result = []
    max_val = numbers[0]
    for num in numbers:
        if num > max_val:
            max_val = num
        result.append(max_val)
    return result
```
```


### humaneval HumanEval/14 (base passes, fine-tuned fails)
**Base:**
```
```python
from typing import List


def all_prefixes(string: str) -> List[str]:
    """ Return list of all prefixes from shortest to longest of the input string
    >>> all_prefixes('abc')
    ['a', 'ab', 'abc']
    """
    return [string[:i+1] for i in range(len(string))]
```
```
**Fine-tuned:**
```
```python
from typing import List


def all_prefixes(string: str) -> List[str]:
    """ Return list of all prefixes from shortest to longest of the input string
    >>> all_prefixes('abc')
    ['a', 'ab', 'abc']
    """
    return [string[:i] for i in range(len(string) + 1)]
```
```


### humaneval HumanEval/24 (base passes, fine-tuned fails)
**Base:**
```
```python
def largest_divisor(n: int) -> int:
    """ For a given number n, find the largest number that divides n evenly, smaller than n
    >>> largest_divisor(15)
    5
    """
    for i in range(n//2, 0, -1):
        if n % i == 0:
            return i
    return 1
```
```
**Fine-tuned:**
```
```python
def largest_divisor(n: int) -> int:
    for i in range(n, 0, -1):
        if n % i == 0:
            return i
```
```


### humaneval HumanEval/1 (both fail)
**Base:**
```
```python
from typing import List

def separate_paren_groups(paren_string: str) -> List[str]:
    stack = []
    result = []
    current_group = ""
    
    for char in paren_string:
        if char == '(':
            stack.append(current_group)
            current_group += char
        elif char == ')':
            stack.append(current_group)
            result.append(''.join(stack.pop()))
            current_group = ""
    
    return result
```
```
**Fine-tuned:**
```
```python
from typing import List

def separate_paren_groups(paren_string: str) -> List[str]:
    """ Input to this function is a string containing multiple groups of nested parentheses. Your goal is to
    separate those group into separate strings and return the list of those.
    Separate groups are balanced (each open brace is properly closed) and not nested within each other
    Ignore any spaces in the input string.
    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['()', '(())', '(()())']
    """
    stack = []
    result = []
    for char in paren_string:
        if char == '(':
            stack.append(char)
        elif char == ')':
            while stack and stack[-1] == '(':
                stack.pop()
            if not stack:
                result.append(''.join(stack))
                stack = []
            else:
                stack.pop()
    return result
```
```


### humaneval HumanEval/6 (both fail)
**Base:**
```
```python
from typing import List

def parse_nested_parens(paren_string: str) -> List[int]:
    stack = []
    levels = []

    for paren in paren_string:
        if paren == '(':
            stack.append(paren)
        elif paren == ')':
            levels.append(len(stack))
            stack.pop()

    return levels
```
```
**Fine-tuned:**
```
```python
from typing import List

def parse_nested_parens(paren_string: str) -> List[int]:
    """ Input to this function is a string represented multiple groups for nested parentheses separated by spaces.
    For each of the group, output the deepest level of nesting of parentheses.
    Eg. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """
    max_level = 0
    current_level = 0
    for char in paren_string:
        if char == '(':
            current_level += 1
            max_level = max(max_level, current_level)
        elif char == ')':
            current_level -= 1
    return [max_level]
```
```


### humaneval HumanEval/10 (both fail)
**Base:**
```
```python

def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    """ Find the shortest palindrome that begins with a supplied string.
    Algorithm idea is simple:
    - Find the longest postfix of supplied string that is a palindrome.
    - Append to the end of the string reverse of a string prefix that comes before the palindromic suffix.
    >>> make_palindrome('')
    ''
    >>> make_palindrome('cat')
    'catac'
    >>> make_palindrome('cata')
    'catac'
    """
    n = len(string)
    for i in range(n):
        # Check for palindrome in postfix
        postfix = string[i:]
        if is_palindrome(postfix):
            # Find the longest prefix that is a palindrome
            prefix = string[:i]
            while is_palindrome(prefix):
                prefix = prefi
```
**Fine-tuned:**
```
```python
def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    """ Find the shortest palindrome that begins with a supplied string.
    Algorithm idea is simple:
    - Find the longest postfix of supplied string that is a palindrome.
    - Append to the end of the string reverse of a string prefix that comes before the palindromic suffix.
    >>> make_palindrome('')
    ''
    >>> make_palindrome('cat')
    'catac'
    >>> make_palindrome('cata')
    'catac'
    """
    for i in range(len(string)):
        for j in range(len(string) - 1, -1, -1):
            if string[i:j + 1] == string[i:j + 1][::-1]:
                return string[:i] + string[j + 1:][::-1] + string[i:j + 1]
    return string
```
```


## mbpp: fine-tuned passes, base fails = 27, base passes, fine-tuned fails = 23, both fail = 164


### mbpp 14 (fine-tuned passes, base fails)
**Base:**
```
```python
def find_Volume(base1, base2, height):
    # The volume of a triangular prism is given by the formula: base1 * base2 * height
    volume = base1 * base2 * height
    return volume
```
```
**Fine-tuned:**
```
```python
def find_Volume(base, height, length):
    return (base * height * length) / 2
```
```


### mbpp 19 (fine-tuned passes, base fails)
**Base:**
```
```python
def find_duplicate(arr):
    seen = set()
    for num in arr:
        if num in seen:
            return True
        seen.add(num)
    return False
```
```
**Fine-tuned:**
```
```python
def test_duplicate(arr):
    seen = set()
    for num in arr:
        if num in seen:
            return True
        seen.add(num)
    return False
```
```


### mbpp 57 (fine-tuned passes, base fails)
**Base:**
```
```python
def find_Max_Num(digits):
    # Convert list of digits into a string
    str_digits = str(digits)
    # Sort the digits in descending order
    sorted_digits = sorted(str_digits, reverse=True)
    # Join the sorted digits back into a string
    max_num_str = ''.join(sorted_digits)
    # Convert the string back to an integer
    max_num = int(max_num_str)
    return max_num
```
```
**Fine-tuned:**
```
```python
def find_Max_Num(digits):
    digits.sort(reverse=True)
    result = ""
    for digit in digits:
        result += str(digit)
    return int(result)
```
```


### mbpp 98 (base passes, fine-tuned fails)
**Base:**
```
```python
import math

def multiply_num(numbers):
    product = 1
    for num in numbers:
        product *= num
    return product / len(numbers)

# Test the function
assert math.isclose(multiply_num((8, 2, 3, -1, 7)), -67.2, rel_tol=0.001)
```
```
**Fine-tuned:**
```
```python
import math

def multiply_num(nums):
    return sum(nums) / len(nums)
```
```


### mbpp 145 (base passes, fine-tuned fails)
**Base:**
```
```python
def max_Abs_Diff(arr):
    return max(abs(a-b) for a in arr for b in arr)
```
```
**Fine-tuned:**
```
```python
def max_Abs_Diff(arr):
    return max(abs(arr[i] - arr[j]) for i in range(len(arr)) for j in range(i+1, len(arr)))
```
```


### mbpp 170 (base passes, fine-tuned fails)
**Base:**
```
```python
def sum_range_list(lst, start_index, end_index):
    return sum(lst[start_index:end_index+1])
```
```
**Fine-tuned:**
```
```python
def sum_range_list(lst, start, end):
    return sum(lst[start-1:end])
```
```


### mbpp 6 (both fail)
**Base:**
```
```python
def differ_At_One_Bit_Pos(num1, num2):
    # Convert numbers to binary and compare bit by bit
    return bin(num1) == bin(num2)[2:].zfill(32)
```
```
**Fine-tuned:**
```
```python
def differ_At_One_Bit_Pos(a, b):
    return bin(a ^ b).count('1') == 2
```
```


### mbpp 7 (both fail)
**Base:**
```
```python
def find_char_long(input_string):
    return {word for word in input_string.split() if len(word) >= 4}
```
```
**Fine-tuned:**
```
```python
def find_char_long(s):
    return set(word for word in s.split() if len(word) >= 4)
```
```


### mbpp 11 (both fail)
**Base:**
```
```python
def remove_Occ(s, char):
    return s[:len(s)-2] + s[-1:]
```
```
**Fine-tuned:**
```
```python
def remove_Occ(s, c):
    return s[1:-1] if s[0] == c and s[-1] == c else s
```
```
